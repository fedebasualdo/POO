<?php
class Carroceria {
    protected $tipo;

    public function __construct($tipo) {
        $this->tipo = $tipo;
    }
}
?>
