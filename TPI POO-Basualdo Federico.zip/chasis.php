<?php
class Chasis {
    protected $material;

    public function __construct($material) {
        $this->material = $material;
    }
}
?>

