<?php
class Motor {
    protected $tipo;

    public function __construct($tipo) {
        $this->tipo = $tipo;
    }
}
?>
